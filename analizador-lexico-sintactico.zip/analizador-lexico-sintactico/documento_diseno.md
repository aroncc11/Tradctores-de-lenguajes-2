# Documento de Diseño — Analizador Léxico y Sintáctico

**Proyecto:** Desarrollo de un traductor (compilador/intérprete) — Fase actual: Análisis Léxico y Sintáctico
**Materia:** Seminario de Solución de Problemas de Traductores de Lenguaje II

---

## 1. Descripción general

Este entregable implementa las dos primeras fases de un traductor
para un lenguaje de programación simplificado (tipo C, con
funciones, tipos `int`/`float`, control de flujo `if`/`else`/`while`,
y expresiones aritméticas/lógicas):

1. **Analizador léxico** (`analizador_lexico.py`) — convierte el
   código fuente en una secuencia de tokens.
2. **Analizador sintáctico** (`analizador_sintactico.py`) — recibe
   esos tokens y verifica que formen un programa gramaticalmente
   válido, usando un análisis ascendente LR (shift-reduce).

Ambas fases están conectadas: el sintáctico no vuelve a leer el
código fuente ni tokeniza nada por su cuenta — usa directamente la
lista de tokens que produce el léxico.

---

## 2. Tokens del lenguaje

Los tokens se definen con un código numérico fijo (0-23), que es el
mismo que usa la tabla del analizador sintáctico para indexar sus
acciones:

| Código | Token | Código | Token |
|:---:|---|:---:|---|
| 0 | identificador | 12 | `;` |
| 1 | entero | 13 | `,` |
| 2 | real | 14 | `(` |
| 3 | cadena | 15 | `)` |
| 4 | tipo (`int`, `float`, `void`) | 16 | `{` |
| 5 | opSuma (`+`, `-`) | 17 | `}` |
| 6 | opMul (`*`, `/`) | 18 | `=` |
| 7 | opRelac (`<`,`>`,`<=`,`>=`) | 19 | `if` |
| 8 | opOr (`\|\|`) | 20 | `while` |
| 9 | opAnd (`&&`) | 21 | `return` |
| 10 | opNot (`!`) | 22 | `else` |
| 11 | opIgualdad (`==`, `!=`) | 23 | `$` (fin de entrada) |

**Reglas léxicas:**
- `identificador = letra (letra | digito)*`
- `entero = digito+`
- `real = entero . entero` (un punto seguido de al menos un dígito)
- `cadena = " ... "` (texto entre comillas dobles)
- Palabras reservadas (`if`, `while`, `return`, `else`, `int`,
  `float`, `void`) se reconocen igual que un identificador y luego
  se reclasifican si coinciden con la lista de reservadas.

---

## 3. Diseño del analizador léxico

### Decisión de diseño: expresiones regulares por categoría de token

El léxico reconoce cada categoría de token (identificador, entero,
real, cadena) con una expresión regular propia, probadas en orden en
cada posición del texto. `real` se intenta antes que `entero` para
que `12.5` no se reconozca como el entero `12` dejando el `.5`
suelto.

### Estructura

- `Tok` (`dataclass`): guarda código, valor (lexema), línea y
  columna.
- `analizador_lexico(src)`: función que recorre la entrada con un
  índice que avanza conforme se reconocen tokens, probando en cada
  posición: espacios/comentarios, `real`, `entero`, `cadena`,
  identificador/palabra reservada, operadores de 2 caracteres,
  operadores/delimitadores de 1 carácter, y por último error.

### Manejo de errores léxicos

Un error léxico ocurre cuando:
- Un número tiene un punto decimal sin dígitos después (`3.`).
- Aparece un carácter que no pertenece a ningún patrón del lenguaje
  (por ejemplo `@`, `#`).

**Decisión clave:** los errores léxicos **no detienen el análisis**.
Cada error se agrega a una lista (`analizador_lexico.errores`) con su
línea, columna y una descripción, y el análisis continúa con el
siguiente carácter. Esto permite reportar **todos** los errores
léxicos de un archivo en una sola pasada, en vez de obligar al
usuario a corregir uno y volver a correr el analizador para ver el
siguiente.

Los tokens marcados como error (código `-1`) se filtran antes de
pasarlos al analizador sintáctico (ver sección 5) — no tendría
sentido intentar dar significado gramatical a un carácter que ni
siquiera es un token válido.

---

## 4. Diseño del analizador sintáctico

### Decisión de diseño: leer directamente el archivo `.lr` oficial

Según `DescripcionArchivosGramaticas.pdf` (proporcionado por el
profesor), cada gramática tiene tres archivos asociados, pero el
programa solo debe leer uno de ellos:

- `*.csv` — la tabla LR(1) para verla desde Excel. **No** lo lee el
  programa.
- `*.inf` — códigos de token y las reglas numeradas, en texto. Es
  referencia; **no** lo lee el programa.
- `*.lr` — la tabla LR(1) codificada como matriz de enteros. **Este
  sí** lo lee el programa.

`analizador_sintactico.py` carga la gramática completa (52 reglas y
tabla de 95 × 46) desde `datos/compilador.lr` con
`cargar_gramatica_lr()`, siguiendo el formato exacto del PDF: primero
el número de reglas, luego una línea por regla
(`idColumnaIzquierda  longitud  nombreIzquierda`), luego
`numFilas numColumnas`, y por último la tabla misma como matriz de
enteros (positivo = desplazar/ir a ese estado; negativo = reducir con
la regla `-celda - 1`, donde regla `0` es aceptar; cero = error).

Esta decisión reemplazó un diseño anterior que partía la gramática en
dos archivos CSV propios (`reglas.csv` + `compilador.csv`); se
descartó en cuanto se tuvo la especificación oficial del formato
`.lr`, para apegarse exactamente a lo que pide la práctica.

### Sin traducir nombres entre léxico y sintáctico

La columna de la tabla para un **token** es directamente su código
numérico (0-23), el mismo que ya produce el analizador léxico. La
columna para un **GOTO** (tras una reducción) es el
`idColumnaIzquierda` que la propia regla trae en el `.lr`. No existe
ningún diccionario intermedio que traduzca nombres de columna: ambas
fases comparten los mismos números desde el diseño.

### Estructura de datos: pila de objetos

La pila del analizador no es una lista de enteros ni de tuplas: es
una jerarquía de clases (`ElementoPila` como clase base abstracta, y
`Terminal`, `NoTerminal`, `Estado` como subclases), cada una con su
propio método `muestra()`. Esto permite que la pila se imprima de
forma legible en cualquier momento del análisis, y que el código que
manipula la pila (`push`/`pop`) trabaje con objetos con significado
propio en vez de números sueltos cuyo papel hay que recordar aparte.

### Algoritmo (shift-reduce)

En cada paso, el analizador consulta `tabla[estado][token.codigo]`,
donde `estado` es la cima de la pila:

1. **Celda > 0 → desplazar (shift)** — mete el token a la pila junto
   con el nuevo estado, y avanza a leer el siguiente token.
2. **Celda < 0, regla ≠ 0 → reducir** — saca de la pila `longitud`
   símbolos (con su estado cada uno) y mete el no terminal
   correspondiente, buscando el nuevo estado con
   `tabla[estado_previo][idColumnaIzquierda]`.
3. **Celda < 0, regla = 0 → aceptar** — el programa es
   sintácticamente correcto.
4. **Celda = 0 → error sintáctico.**

### Manejo de errores sintácticos

A diferencia del léxico, un error sintáctico **sí detiene el
análisis**: una vez que la secuencia de tokens no puede completar
ninguna estructura gramatical válida, no hay forma consistente de
"adivinar" cómo seguir sin arriesgar reportar errores en cascada que
no reflejan el problema real. El analizador lanza una excepción
(`ErrorSintactico`) con la línea y columna exactas del token que
causó el problema.

### Construcción del árbol sintáctico

El análisis no se limita a decir "aceptado" o "rechazado": en cada
reducción, los símbolos que se sacan de la pila se guardan como
`hijos` del `NoTerminal` recién creado, en vez de descartarse. Así,
cuando el análisis acepta la cadena, `analizar()` regresa la **raíz
del árbol sintáctico completo** (el nodo `programa`), con toda su
estructura de derivación debajo — no solo el resultado booleano. El
método `NoTerminal.imprimir_arbol()` lo despliega como árbol de texto
para inspección visual.

---

## 5. Cómo se conectan el léxico y el sintáctico

`analizar_programa()` en `analizador_sintactico.py` es el puente
entre ambas fases:

1. Llama a `analizador_lexico(codigo_fuente)` y obtiene la lista de
   tokens (`Tok`), cada uno con su código numérico 0-23.
2. Descarta los tokens de error léxico (código `-1`) del flujo hacia
   el sintáctico, pero conserva la lista de errores léxicos aparte
   para reportarlos.
3. Entrega el resto de los tokens, tal cual, al analizador
   sintáctico — sin traducir ni envolver nada, porque el código de
   cada `Tok` ya es el índice de columna que la tabla necesita.

Esto refleja el diseño real de un compilador: el léxico y el
sintáctico son fases independientes que se comunican únicamente a
través de la secuencia de tokens — el sintáctico nunca ve el texto
fuente original.

---

## 6. Limitaciones conocidas / decisiones pendientes

- El patrón de `cadena` (texto entre comillas dobles) se asumió por
  convención, ya que la especificación no detalla su formato exacto
  (por ejemplo, si admite escapes como `\"`).
- La palabra reservada `void` se agrupó bajo el token `tipo` junto
  con `int` y `float`, aunque la lista original de palabras
  reservadas del proyecto solo mencionaba explícitamente `int` y
  `float`.
- El analizador sintáctico reporta el primer error y se detiene (no
  implementa recuperación de errores sintácticos), a diferencia del
  léxico que sí reporta todos los errores en una sola pasada.

---

## 7. Estructura de archivos entregados

```
analizador_lexico.py          -> Fase 1: código fuente -> tokens
analizador_sintactico.py       -> Fase 2: tokens -> aceptado/rechazado
README.md                       -> Guía rápida de la entrega
datos/
  compilador.lr                  -> tabla LR + reglas (esto sí lo lee el programa)
  compilador.csv                  -> la misma tabla, para verla en Excel
  compilador_inf.txt               -> códigos de token y reglas, de referencia
ejemplos/
  ejemplo1_valido.txt                        + salida1_valido.txt
  ejemplo2_error_lexico.txt                   + salida2_error_lexico.txt
  ejemplo3_error_sintactico.txt                + salida3_error_sintactico.txt
  ejemplo4_funciones_anidadas.txt               + salida4_funciones_anidadas.txt
  ejemplo5_expresiones_complejas.txt             + salida5_expresiones_complejas.txt
  ejemplo6_multiples_errores_lexicos.txt          + salida6_multiples_errores_lexicos.txt
  ejemplo7_error_sintactico_parentesis.txt         + salida7_error_sintactico_parentesis.txt
```
